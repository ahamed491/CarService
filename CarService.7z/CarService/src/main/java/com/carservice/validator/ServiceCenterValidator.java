package com.carservice.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.carservice.model.ServiceCenterDetails;

@Component
public class ServiceCenterValidator implements Validator{

	@Override
	public boolean supports(Class<?> center) {
		return ServiceCenterDetails.class.equals(center);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ServiceCenterDetails serviceCenter = (ServiceCenterDetails)target;
		if(serviceCenter.getServiceTypes().length==0) {
			errors.rejectValue("serviceTypes", null, "Choose a service type");
		}
		
	}

}