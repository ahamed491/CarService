//package com.carservice.validator;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import org.springframework.validation.Errors;
//import org.springframework.validation.ValidationUtils;
//import org.springframework.validation.Validator;
//
//import com.carservice.model.Login;
//import com.carservice.service.ServiceCar;
//
//@Component
//public class LoginValidator implements Validator {
//
////	
////	@Autowired
////	ServiceCar service;
////	
////	@Override
////	public boolean supports(Class<?> login) {
////		// TODO Auto-generated method stub
////		return Login.class.equals(login);
////	}
////
////	@Override
////	public void validate(Object target, Errors errors) {
////		// TODO Auto-generated method stub
////		Login log = (Login)target;
////		
////		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userId", "Invalid UserName or Password");
////		
////		
////		if(service.checkId(log.getUserId()) == null) {
////			errors.rejectValue("userId", null, "Enter valid UserId or Email");
////		}
////		
////		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "Invalid UserName or Password");
////	   
////		if(!(log.getPassword().matches("^(?=.*\\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[^\\w\\d\\s:])([^\\s]){8,16}$"))) {
////			   errors.rejectValue("password", null, "Enter valid password with minimum 6 characters with at least an uppercase character, a special symbol, a digit and a lowercase character");	
////			}
////	
////	}
//
//}
