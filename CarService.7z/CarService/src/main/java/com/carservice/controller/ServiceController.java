package com.carservice.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.carserive.dao.LoginDAO;
import com.carserive.dao.ServiceCenterDAO;
import com.carservice.model.ServiceCenterDetails;
import com.carservice.validator.ServiceCenterValidator;

@Controller
public class ServiceController {
	@Autowired
	private ServiceCenterValidator scv;
	@Autowired
	private ServiceCenterDAO scdao;
	@Autowired
	private LoginDAO ldao;
	int vend_id;
	@RequestMapping("/addCenter")
	public String showServicecenter(@ModelAttribute("serviceCenter")ServiceCenterDetails service,Model model)
	{
		int id = 0;
		model.addAttribute("id",id);
		return "Addservice";

	}
	@RequestMapping(value="/submitCenter",method = RequestMethod.POST)
	public String addServiceCenter(@ModelAttribute("serviceCenter")ServiceCenterDetails service,BindingResult result,HttpSession session)
	{
		vend_id = Integer.parseInt(session.getAttribute("id").toString());
		System.out.println(session.getAttribute("id"));
		boolean isCenterAdded = false;
		scv.validate(service, result);
		if(result.hasErrors())
			return "Addservice";
		try {
		isCenterAdded = scdao.addCenter(service,vend_id);
		System.out.println(isCenterAdded);
		}
		catch(Exception e)
		{
		}
		if(isCenterAdded == true)
			return "vendorHome";
		else
			return "Addservice";
	}
	@ModelAttribute("serviceTypesList")
	public List<String> generateServiceTypes(){
		List<String> serviceTypes = new ArrayList<>();
		serviceTypes.add("Car wash");
		serviceTypes.add("Car Paint");
		serviceTypes.add("Car Repair");
		serviceTypes.add("Car AC service");
		return serviceTypes;
		
	}
	
	@RequestMapping(value = "/viewServices")
	public String ListAllServiceCenters(Model model,HttpSession session)
	{
		ServiceCenterDetails serviceDetails = new ServiceCenterDetails();
		vend_id = Integer.parseInt(session.getAttribute("id").toString());
		List<ServiceCenterDetails> services = scdao.getAllServiceCentersList(vend_id);
		model.addAttribute("serviceCentersList",services);
		return "viewCenterList";
	}
	
	@RequestMapping(value = "/edit")
	public String editCenter(@ModelAttribute("serviceCenter")ServiceCenterDetails service,Model model,@RequestParam("id") int id)
	{
		ServiceCenterDetails serviceTypes = scdao.findcenterById(id);
		service.setName(serviceTypes.getName());
		service.setContactNumber(serviceTypes.getContactNumber());
		service.setAddress(serviceTypes.getAddress());
		service.setStartTime(serviceTypes.getStartTime());
		service.setEndTime(serviceTypes.getEndTime());
		service.setLocation(serviceTypes.getLocation());
		service.setLat(serviceTypes.getLat());
		service.setLon(serviceTypes.getLon());
		model.addAttribute("id",id);
		return "Addservice";
	}
}
