package com.carservice.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.carserive.dao.LoginDAO;
import com.carservice.model.Login;
import com.carservice.service.ServiceCar;

@Controller
@SessionAttributes("id")
public class LoginController {
	@Autowired
	private ServiceCar service;
	@Autowired
	LoginDAO ldao;
	@RequestMapping(value="/")
	public String Homes() {
		
		return "redirect:login";
	}
	@RequestMapping(value="/login",method = RequestMethod.GET)
	public String LoginPage(@ModelAttribute("login")Login login) {
		
		return "login";
	}
	@RequestMapping(value="/login",method = RequestMethod.POST)
	public String Login(@ModelAttribute("login")Login login,BindingResult result,ModelMap model ,HttpSession session) {
		
		String userDetails = ldao.validateUser(login);
		String message="";
	    String s[] = new String[2];
	    String id;
	    String loginType;
	   
	   // 
	    message="Invalid username or password";
		if(userDetails != null)
		{
			//System.out.println(userDetails);
			s=userDetails.split(",");
			id=s[0];
			loginType=s[1];
			System.out.println(id);
			session.setAttribute("id",id);
			session.setAttribute("loginType", loginType);
			if(s[1].equals("user"))
			{
				return "user";
			}
			else if(s[1].equals("admin"))
			{
				
				return "redirect:adminHome";
			}
			else if(s[1].equals("vendor"))
			{   
				message="admin approval pending";
				String vendorStatus = ldao.validateVendorStatus(login);
				if(vendorStatus.equals("approved"))
				return "redirect:vendorHome";
			}
		}
		
		model.addAttribute("message", message);
		login.setPassword("");
		login.setUserId("");
		return "login";
	}
	
	@RequestMapping(value="/logout",method=RequestMethod.GET)
	public String logout(HttpServletRequest request,HttpSession session,HttpServletResponse response) {
		session=request.getSession();
	    
		session.invalidate();
		response.setHeader("pragma", "no-cache");              
        response.setHeader("Cache-control", "no-cache, no-store, must-revalidate");             
        response.setHeader("Expires", "0"); 
       // System.out.println(session.getAttribute("id"));
		return "redirect:login";
	}
	

}
