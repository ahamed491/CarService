package com.carservice.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.carservice.model.ServiceCenterDetails;
@Controller
public class VendorController {
	@RequestMapping(value="/vendorHome",method=RequestMethod.GET)
	public String vendorHome(HttpSession session) {
		
		if(session.getAttribute("id")==null||(!session.getAttribute("loginType").equals("vendor"))) {
			return "redirect:/login";}
		
		return "vendorHome";
	}
 

}
