package com.carserive.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.carservice.model.ServiceCenterDetails;

public class CenterRowMapper implements RowMapper<ServiceCenterDetails>{

	@Override
	public ServiceCenterDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		ServiceCenterDetails service = new ServiceCenterDetails();
		service.setCenterId(rs.getInt("center_id"));
		service.setName(rs.getString("name"));
		String serviceTypes = rs.getString("serviceType");
		String services[] = serviceTypes.split(",");
		service.setServiceTypes(services);
		service.setContactNumber(rs.getString("phonenumber"));
		service.setLocation(rs.getString("location"));
		service.setStartTime(rs.getTime("start_time").toLocalTime());
		service.setEndTime(rs.getTime("end_time").toLocalTime());
		service.setAddress(rs.getString("address"));
		
		return service;
	}

}
