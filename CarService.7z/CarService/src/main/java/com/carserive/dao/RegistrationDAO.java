package com.carserive.dao;

import com.carservice.model.Register;

public interface RegistrationDAO {
	public boolean adduser(Register register,String type);
}
