package com.carserive.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalTime;

import org.springframework.jdbc.core.RowMapper;

import com.carservice.model.ServiceCenterDetails;

public class ServiceCenterDetailsMapper implements RowMapper<ServiceCenterDetails> {


	@Override
	public ServiceCenterDetails mapRow(ResultSet rs, int rn) throws SQLException {
		
		ServiceCenterDetails scd = new ServiceCenterDetails();
		scd.setCenterId(rs.getInt("center_id"));
		scd.setName(rs.getString("name"));
		scd.setAddress(rs.getString("Address"));
		scd.setContactNumber(rs.getString("phonenumber"));
		String[] s = rs.getString("servicetype").split(",");
		scd.setServiceTypes(s);
		scd.setLocation(rs.getString("location"));
//		scd.setStartTime(java.sql.Time.valueOf(rs.getTime("start_time")));
//		scd.setEndTime(rs.getTime("end_time"));
		scd.setLat(rs.getFloat("latitude"));
		scd.setLon(rs.getFloat("longitude"));
		return null;
	}

}
