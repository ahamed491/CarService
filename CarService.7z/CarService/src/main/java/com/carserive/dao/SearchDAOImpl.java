package com.carserive.dao;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.carservice.model.Search;
import com.carservice.model.ServiceCenterDetails;

@Service
public class SearchDAOImpl implements SearchDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	private final String sname = "SELECT * from service_center_details where name LIKE '%?%'";
	private final String stype = "SELECT * from service_center_details where servicetype LIKE '%?%'";
	private final String slocation = "SELECT * from service_center_details where location=?";
	private final String swhole = "SELECT * from service_center_details";
	
	@Override
	public ArrayList<ServiceCenterDetails> searchDatabase(Search search) {
		String type = search.getServiceCenter();
		String name = search.getSearch();
		ArrayList<ServiceCenterDetails> li = new ArrayList<>();
		if(type.equals("Nmae")) {
			li = (ArrayList<ServiceCenterDetails>) jdbcTemplate.query(sname, new ServiceCenterDetailsMapper(), name);
		}
		else if(type.equals("Type")) {
			li = (ArrayList<ServiceCenterDetails>) jdbcTemplate.query(stype, new ServiceCenterDetailsMapper(), name);
		}
		else if(type.equals("Location")){
			li = (ArrayList<ServiceCenterDetails>) jdbcTemplate.query(slocation, new ServiceCenterDetailsMapper(), name);
		}
		else {
			li = (ArrayList<ServiceCenterDetails>) jdbcTemplate.query(swhole, new ServiceCenterDetailsMapper(), name);
		}
		return li;
	}

}
