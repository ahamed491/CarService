package com.carserive.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.stereotype.Service;

import com.carservice.model.Register;

@Service
public class RegistrationDAOImpl implements RegistrationDAO {

		@Autowired
		private JdbcTemplate jdbcTemplate;
		private final String INSERT_SQL_VENDOR = "INSERT INTO user_details(firstname,lastname,contactnumber,email,password,usertype)values(?,?,?,?,?,?)";
		public boolean adduser(Register register, String type) {
			jdbcTemplate.update(new PreparedStatementCreator() {
				@Override
				public PreparedStatement createPreparedStatement(Connection connection){
					try {
					PreparedStatement ps = connection.prepareStatement(INSERT_SQL_VENDOR, Statement.RETURN_GENERATED_KEYS);
					ps.setString(1, register.getFirstName());
					ps.setString(2, register.getLastName());
					ps.setString(3, register.getContactNumber());
					ps.setString(4, register.getEmail());
					ps.setString(5, register.getPassword());
					ps.setString(6,type);
					return ps;
				}
				catch(SQLException s)
					{
						
					}
					return null;
				}
				});	
					return true;

				

		}
	}

