package com.carserive.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.stereotype.Service;

import com.carservice.model.VendorRegistration;

@Service
public class VendorRegistrationDAOImpl implements VendorRegistrationDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private final String pending_vendor_list = "SELECT * from vendor_details where approved_status = 'pending'";
	private final String INSERT_SQL_VENDOR = "INSERT INTO Vendor_Details(firstname,lastname,age,gender,contactnumber,vendor_id,password,approved_status)values(?,?,?,?,?,?,?,?)";

	@Override
	public boolean addVendor(VendorRegistration registerVendor) {
		jdbcTemplate.update(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection connection) {
				try {
					PreparedStatement ps = connection.prepareStatement(INSERT_SQL_VENDOR,
							Statement.RETURN_GENERATED_KEYS);
					ps.setString(1, registerVendor.getFirstName());
					ps.setString(2, registerVendor.getLastName());
					ps.setInt(3, registerVendor.getAge());
					ps.setString(4, registerVendor.getGender());
					ps.setString(5, registerVendor.getContactNumber());
					ps.setString(6, registerVendor.getVendorId());
					ps.setString(7, registerVendor.getPassword());
					ps.setString(8, "pending");
					return ps;
				} catch (SQLException s) {

				}
				return null;
			}
		});
		return true;

	}

	@Override
	public List<VendorRegistration> getPendingVendorsList() {

		List<VendorRegistration> pendingVendorsList = new ArrayList<>();
		
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(pending_vendor_list);
		
		for(Map row : rows)
		{
			VendorRegistration vendorRegistration = new VendorRegistration();
			
			vendorRegistration.setVendorId(String.valueOf( row.get("VEND_ID")));
			vendorRegistration.setFirstName((String)row.get("FIRSTNAME")+" "+row.get("LASTNAME"));
			vendorRegistration.setAge((int)row.get("AGE"));
			vendorRegistration.setGender((String)row.get("GENDER"));
			vendorRegistration.setContactNumber(String.valueOf(row.get("CONTACTNUMBER")));
			pendingVendorsList.add(vendorRegistration);
			
		}
				

		return pendingVendorsList;
	}

	public void approveVendor(int id) {
		
		jdbcTemplate.update("update vendor_details set approved_status ='approved' where vend_id='"+id+"'");
	}

	public void rejectVendor(int id) {
		jdbcTemplate.update("update vendor_details set approved_status ='invalid' where vend_id='"+id+"'");
	}
}








//VendorRegistration vendorRegistration = new VendorRegistration();
//vendorRegistration.setVendorId(rs.getString(1));
//vendorRegistration.setFirstName(rs.getString(2) + " " + rs.getString(3));
//vendorRegistration.setAge(rs.getInt(4));
//vendorRegistration.setGender(rs.getString(5));
//vendorRegistration.setContactNumber(rs.getString(6));
