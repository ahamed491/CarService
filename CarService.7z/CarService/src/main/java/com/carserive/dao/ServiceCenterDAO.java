package com.carserive.dao;

import java.util.List;

import com.carservice.model.ServiceCenterDetails;

public interface ServiceCenterDAO {
	public boolean addCenter(ServiceCenterDetails serviceCenterdetails,int vend_id);

	public List<ServiceCenterDetails> getAllServiceCentersList(int vend_id);
	
	public ServiceCenterDetails findcenterById(int id);
}
