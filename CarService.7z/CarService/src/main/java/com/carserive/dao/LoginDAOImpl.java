package com.carserive.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.carservice.model.Login;

@Service
public class LoginDAOImpl implements LoginDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Override
	public String validateUser(Login login) {

		String userId = login.getUserId();

		String password = login.getPassword();
		
		int id;

		String sql1 = "SELECT User_id FROM USER_DETAILS WHERE EMAIL='" + userId + "' AND PASSWORD='" + password + "'";

		String sql2 = "SELECT vend_id FROM VENDOR_DETAILS WHERE VENDOR_ID = '" + userId + "' AND PASSWORD = '"
				+ password + "'";
		try {
			
			id =  Integer.parseInt(jdbcTemplate.queryForObject(sql1, new Object[] {}, String.class));
		
			String type = jdbcTemplate.queryForObject(
					"SELECT usertype FROM USER_DETAILS WHERE EMAIL='" + userId + "' AND PASSWORD='" + password + "'",
					new Object[] {}, String.class);
			return id + "," + type;

		} catch (Exception e) {
		
			try {
				id =  Integer.parseInt(jdbcTemplate.queryForObject(sql2, new Object[] {}, String.class));
			
				return id + ",vendor";
			} catch (Exception E) {
				
				return null;
			}
		}

	}

	@Override
	public String validateVendorStatus(Login login) {

		String userId = login.getUserId();
		String sql = "select approved_status from vendor_details where vendor_id='" + userId + "'";
		String status = (String) jdbcTemplate.queryForObject(sql, new Object[] {}, String.class);
		return status;
	}

}