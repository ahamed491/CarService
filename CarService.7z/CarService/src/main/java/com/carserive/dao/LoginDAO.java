package com.carserive.dao;

import com.carservice.model.Login;

public interface LoginDAO {
	public String validateUser(Login login);
	
	public String validateVendorStatus(Login login);
}
