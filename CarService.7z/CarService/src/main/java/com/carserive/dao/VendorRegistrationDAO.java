package com.carserive.dao;

import java.util.List;
import java.util.Map;

import com.carservice.model.VendorRegistration;

public interface VendorRegistrationDAO {
	public boolean addVendor(VendorRegistration registerVendor);
	
	public List<VendorRegistration> getPendingVendorsList();
	
}
